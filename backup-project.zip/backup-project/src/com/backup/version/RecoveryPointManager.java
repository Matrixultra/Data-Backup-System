package com.backup.version;

import com.backup.data.BackupData;
import com.backup.data.RecoveryPoint;
import com.backup.io.BinarySerializer;
import com.backup.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * Tracks named recovery points (a label + pointers to a backup's files
 * across formats) so a user can roll back to a specific moment without
 * having to remember raw file paths.
 */
public class RecoveryPointManager {

    private final String recoveryDir;
    private final BinarySerializer serializer;

    public RecoveryPointManager(String recoveryDir) {
        this.recoveryDir = recoveryDir;
        this.serializer = new BinarySerializer();
        FileUtils.ensureDirectory(recoveryDir);
    }

    /** Registers a new recovery point for a backup that already has files on disk. */
    public RecoveryPoint createRecoveryPoint(BackupData backup, String label,
                                              String binaryPath, String compressedPath,
                                              String csvPath, String jsonPath) throws IOException {
        String id = UUID.randomUUID().toString();
        RecoveryPoint point = new RecoveryPoint(id, backup.getBackupId(), label,
                binaryPath, compressedPath, csvPath, jsonPath);

        String pointFile = recoveryDir + File.separator + "rp_" + id + ".dat";
        try (java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(
                new java.io.FileOutputStream(pointFile))) {
            oos.writeObject(point);
        }

        return point;
    }

    /** Lists every recovery point, most recent first. */
    public List<RecoveryPoint> listRecoveryPoints() throws IOException, ClassNotFoundException {
        List<RecoveryPoint> points = new ArrayList<>();
        File[] files = FileUtils.listFilesWithSuffix(recoveryDir, ".dat");

        for (File f : files) {
            try (java.io.ObjectInputStream ois = new java.io.ObjectInputStream(
                    new java.io.FileInputStream(f))) {
                points.add((RecoveryPoint) ois.readObject());
            }
        }

        points.sort(Comparator.comparing(RecoveryPoint::getCreatedAt).reversed());
        return points;
    }

    /** Restores the BackupData referenced by a recovery point, using its binary file. */
    public BackupData restore(RecoveryPoint point) throws IOException, ClassNotFoundException {
        if (point.getBinaryPath() == null) {
            throw new IOException("Recovery point has no binary file path to restore from");
        }
        return serializer.load(point.getBinaryPath());
    }
}
