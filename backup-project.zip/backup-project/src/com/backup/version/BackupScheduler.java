package com.backup.version;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * Provides automatic, recurring backup scheduling using a single
 * background daemon thread. Call schedule(...) with a Runnable that
 * performs one backup cycle (e.g. BackupManager::createBackup wrapped
 * to supply its own data snapshot).
 */
public class BackupScheduler {

    private final ScheduledExecutorService executor;
    private ScheduledFuture<?> activeTask;

    public BackupScheduler() {
        this.executor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "backup-scheduler");
            t.setDaemon(true);
            return t;
        });
    }

    /**
     * Schedules a backup task to run repeatedly.
     *
     * @param task           the backup logic to run on each tick
     * @param initialDelay   delay before the first run
     * @param period         interval between subsequent runs
     * @param unit           time unit for both delay and period
     */
    public void schedule(Runnable task, long initialDelay, long period, TimeUnit unit) {
        if (activeTask != null && !activeTask.isCancelled()) {
            activeTask.cancel(false);
        }
        activeTask = executor.scheduleAtFixedRate(() -> {
            try {
                task.run();
            } catch (Exception e) {
                System.err.println("Scheduled backup failed: " + e.getMessage());
            }
        }, initialDelay, period, unit);
    }

    /** Convenience method: schedule a daily backup at a fixed interval from now. */
    public void scheduleDaily(Runnable task) {
        schedule(task, 0, 24, TimeUnit.HOURS);
    }

    /** Convenience method: schedule an hourly backup. */
    public void scheduleHourly(Runnable task) {
        schedule(task, 0, 1, TimeUnit.HOURS);
    }

    /** Stops the currently scheduled task, if any. */
    public void cancel() {
        if (activeTask != null) {
            activeTask.cancel(false);
        }
    }

    /** Shuts down the scheduler entirely. Call this on application exit. */
    public void shutdown() {
        executor.shutdown();
    }

    public boolean isRunning() {
        return activeTask != null && !activeTask.isCancelled();
    }
}
