package com.backup.version;

import com.backup.data.BackupData;
import com.backup.io.BinarySerializer;
import com.backup.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Manages historical versions of backups. Every time a backup is created,
 * a copy is also stored in the version directory, named so that versions
 * for the same logical backup id can be tracked and listed in order.
 */
public class VersionManager {

    private final String versionDir;
    private final BinarySerializer serializer;

    public VersionManager(String versionDir) {
        this.versionDir = versionDir;
        this.serializer = new BinarySerializer();
        FileUtils.ensureDirectory(versionDir);
    }

    /** Persists a new version snapshot for the given backup. */
    public void createVersion(BackupData backup) throws IOException {
        String versionFile = versionDir + File.separator + "version_" + backup.getBackupId() + ".dat";
        serializer.save(backup, versionFile);
    }

    /** Loads and returns every stored version, newest first. */
    public List<BackupData> listAllVersions() throws IOException, ClassNotFoundException {
        List<BackupData> versions = new ArrayList<>();
        File[] files = FileUtils.listFilesWithSuffix(versionDir, ".dat");

        for (File file : files) {
            versions.add(serializer.load(file.getPath()));
        }

        versions.sort(Comparator.comparing(BackupData::getBackupTime).reversed());
        return versions;
    }

    /** Finds a specific version by its backup id, or null if not found. */
    public BackupData findVersion(String backupId) throws IOException, ClassNotFoundException {
        String versionFile = versionDir + File.separator + "version_" + backupId + ".dat";
        File f = new File(versionFile);
        if (!f.exists()) return null;
        return serializer.load(versionFile);
    }

    /** Removes a specific version from disk. Returns true if a file was deleted. */
    public boolean deleteVersion(String backupId) throws IOException {
        String versionFile = versionDir + File.separator + "version_" + backupId + ".dat";
        return FileUtils.deleteIfExists(versionFile);
    }

    /** Returns the total number of stored versions. */
    public int versionCount() {
        return FileUtils.listFilesWithSuffix(versionDir, ".dat").length;
    }
}
