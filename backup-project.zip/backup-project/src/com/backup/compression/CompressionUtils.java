package com.backup.compression;

import com.backup.data.BackupData;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Handles GZIP compression/decompression of serialized BackupData objects,
 * plus general-purpose helpers for compressing arbitrary files.
 */
public class CompressionUtils {

    /** Serializes and compresses a BackupData object in one step. */
    public void compressBackup(BackupData backup, String filePath) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(
                new GZIPOutputStream(new FileOutputStream(filePath)))) {
            oos.writeObject(backup);
        }
    }

    /** Decompresses and deserializes a BackupData object in one step. */
    public BackupData decompressBackup(String filePath) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(
                new GZIPInputStream(new FileInputStream(filePath)))) {
            Object obj = ois.readObject();
            if (!(obj instanceof BackupData)) {
                throw new IOException("File does not contain a valid BackupData object: " + filePath);
            }
            return (BackupData) obj;
        }
    }

    /** Compresses an arbitrary file (e.g. a CSV or JSON export) into a .gz file. */
    public void compressFile(String sourcePath, String destPath) throws IOException {
        byte[] buffer = new byte[8192];
        try (FileInputStream fis = new FileInputStream(sourcePath);
             GZIPOutputStream gzos = new GZIPOutputStream(new FileOutputStream(destPath))) {
            int len;
            while ((len = fis.read(buffer)) > 0) {
                gzos.write(buffer, 0, len);
            }
        }
    }

    /** Decompresses a .gz file back into its original raw contents. */
    public void decompressFile(String sourcePath, String destPath) throws IOException {
        byte[] buffer = new byte[8192];
        try (GZIPInputStream gzis = new GZIPInputStream(new FileInputStream(sourcePath));
             FileOutputStream fos = new FileOutputStream(destPath)) {
            int len;
            while ((len = gzis.read(buffer)) > 0) {
                fos.write(buffer, 0, len);
            }
        }
    }

    /** Returns the compression ratio achieved, as a percentage saved (0-100). */
    public double compressionRatioPercent(long originalSize, long compressedSize) {
        if (originalSize <= 0) return 0.0;
        return (1.0 - ((double) compressedSize / originalSize)) * 100.0;
    }
}
