package com.backup;

import com.backup.compression.CompressionUtils;
import com.backup.data.BackupData;
import com.backup.data.RecoveryPoint;
import com.backup.io.BinarySerializer;
import com.backup.io.CSVHandler;
import com.backup.io.FileComparator;
import com.backup.io.FileUtils;
import com.backup.io.JSONHandler;
import com.backup.version.BackupScheduler;
import com.backup.version.RecoveryPointManager;
import com.backup.version.VersionManager;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Central coordinator for the Data Backup System. Wires together
 * serialization, compression, CSV/JSON import-export, version
 * management, recovery points, and scheduling.
 */
public class BackupManager {

    private static final String BACKUP_DIR = "backups" + File.separator;
    private static final String VERSION_DIR = "backups" + File.separator + "versions" + File.separator;
    private static final String RECOVERY_DIR = "backups" + File.separator + "recovery_points" + File.separator;

    private final BinarySerializer binarySerializer;
    private final CompressionUtils compressionUtils;
    private final CSVHandler csvHandler;
    private final JSONHandler jsonHandler;
    private final FileComparator fileComparator;
    private final VersionManager versionManager;
    private final RecoveryPointManager recoveryPointManager;
    private final BackupScheduler scheduler;

    public BackupManager() {
        FileUtils.ensureDirectory(BACKUP_DIR);
        FileUtils.ensureDirectory(VERSION_DIR);
        FileUtils.ensureDirectory(RECOVERY_DIR);

        this.binarySerializer = new BinarySerializer();
        this.compressionUtils = new CompressionUtils();
        this.csvHandler = new CSVHandler();
        this.jsonHandler = new JSONHandler();
        this.fileComparator = new FileComparator();
        this.versionManager = new VersionManager(VERSION_DIR);
        this.recoveryPointManager = new RecoveryPointManager(RECOVERY_DIR);
        this.scheduler = new BackupScheduler();
    }

    /**
     * Creates a full backup: writes binary, compressed, CSV, and JSON
     * formats, registers a version snapshot, and creates a recovery point.
     * Returns the new backup's id.
     */
    public String createBackup(String description, Map<String, Object> data) throws IOException {
        BackupData backup = new BackupData(description, data);
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String baseName = BACKUP_DIR + "backup_" + timestamp;

        String binaryPath = baseName + ".dat";
        String compressedPath = baseName + ".dat.gz";
        String csvPath = baseName + ".csv";
        String jsonPath = baseName + ".json";

        binarySerializer.save(backup, binaryPath);
        compressionUtils.compressBackup(backup, compressedPath);
        csvHandler.exportToCSV(backup, csvPath);
        jsonHandler.exportToJSON(backup, jsonPath);

        versionManager.createVersion(backup);
        recoveryPointManager.createRecoveryPoint(backup, description, binaryPath, compressedPath, csvPath, jsonPath);

        System.out.println("Backup created successfully!");
        System.out.println("Files created:");
        System.out.println("  - " + binaryPath);
        System.out.println("  - " + compressedPath);
        System.out.println("  - " + csvPath);
        System.out.println("  - " + jsonPath);

        return backup.getBackupId();
    }

    public BackupData restoreFromBinary(String filePath) throws IOException, ClassNotFoundException {
        return binarySerializer.load(filePath);
    }

    public BackupData restoreFromCompressed(String filePath) throws IOException, ClassNotFoundException {
        return compressionUtils.decompressBackup(filePath);
    }

    public Map<String, Object> importFromCSV(String filePath) throws IOException {
        return csvHandler.importFromCSV(filePath);
    }

    public BackupData importBackupFromCSV(String filePath) throws IOException {
        return csvHandler.importBackupFromCSV(filePath);
    }

    public BackupData importFromJSON(String filePath) throws IOException {
        return jsonHandler.importFromJSON(filePath);
    }

    public List<BackupData> listAllVersions() throws IOException, ClassNotFoundException {
        return versionManager.listAllVersions();
    }

    public List<RecoveryPoint> listRecoveryPoints() throws IOException, ClassNotFoundException {
        return recoveryPointManager.listRecoveryPoints();
    }

    public BackupData restoreFromRecoveryPoint(RecoveryPoint point) throws IOException, ClassNotFoundException {
        return recoveryPointManager.restore(point);
    }

    public FileComparator.DiffResult compareBackups(BackupData a, BackupData b) {
        return fileComparator.compare(a, b);
    }

    public BackupData mergeBackups(BackupData a, BackupData b, FileComparator.ConflictStrategy strategy, String description) {
        return fileComparator.merge(a, b, strategy, description);
    }

    public void scheduleAutomaticBackups(java.util.function.Supplier<Map<String, Object>> dataSupplier,
                                          String description, long periodSeconds) {
        scheduler.schedule(() -> {
            try {
                createBackup(description, dataSupplier.get());
            } catch (IOException e) {
                System.err.println("Scheduled backup failed: " + e.getMessage());
            }
        }, 0, periodSeconds, TimeUnit.SECONDS);
    }

    public void stopScheduledBackups() {
        scheduler.cancel();
    }

    public void shutdownScheduler() {
        scheduler.shutdown();
    }

    /** Deletes backup files older than the given number of days. Returns count of files removed. */
    public int cleanupOldBackups(int keepDays) {
        File backupDir = new File(BACKUP_DIR);
        if (!backupDir.exists()) return 0;

        File[] files = backupDir.listFiles(File::isFile);
        if (files == null) return 0;

        long cutoffTime = System.currentTimeMillis() - (keepDays * 24L * 60 * 60 * 1000);
        int deleted = 0;

        for (File file : files) {
            if (file.lastModified() < cutoffTime) {
                if (file.delete()) {
                    System.out.println("Deleted old backup: " + file.getName());
                    deleted++;
                }
            }
        }

        return deleted;
    }

    /** Computes and prints aggregate statistics about all backups on disk. */
    public BackupStatistics computeStatistics() {
        File backupDir = new File(BACKUP_DIR);
        long binarySize = 0, compressedSize = 0, csvSize = 0, jsonSize = 0;
        int binaryCount = 0, compressedCount = 0, csvCount = 0, jsonCount = 0;

        File[] files = backupDir.listFiles(File::isFile);
        if (files != null) {
            for (File f : files) {
                String name = f.getName();
                if (name.endsWith(".dat.gz")) {
                    compressedSize += f.length();
                    compressedCount++;
                } else if (name.endsWith(".dat")) {
                    binarySize += f.length();
                    binaryCount++;
                } else if (name.endsWith(".csv")) {
                    csvSize += f.length();
                    csvCount++;
                } else if (name.endsWith(".json")) {
                    jsonSize += f.length();
                    jsonCount++;
                }
            }
        }

        return new BackupStatistics(binarySize, compressedSize, csvSize, jsonSize,
                binaryCount, compressedCount, csvCount, jsonCount);
    }

    /** Simple immutable holder for the statistics screen. */
    public static class BackupStatistics {
        public final long binarySize, compressedSize, csvSize, jsonSize;
        public final int binaryCount, compressedCount, csvCount, jsonCount;

        BackupStatistics(long binarySize, long compressedSize, long csvSize, long jsonSize,
                          int binaryCount, int compressedCount, int csvCount, int jsonCount) {
            this.binarySize = binarySize;
            this.compressedSize = compressedSize;
            this.csvSize = csvSize;
            this.jsonSize = jsonSize;
            this.binaryCount = binaryCount;
            this.compressedCount = compressedCount;
            this.csvCount = csvCount;
            this.jsonCount = jsonCount;
        }

        public long totalSize() {
            return binarySize + compressedSize + csvSize + jsonSize;
        }

        public double compressionRatioPercent() {
            if (binaryCount == 0 || compressedCount == 0 || binarySize == 0) return 0.0;
            double avgBinary = (double) binarySize / binaryCount;
            double avgCompressed = (double) compressedSize / compressedCount;
            return (1.0 - (avgCompressed / avgBinary)) * 100.0;
        }
    }
}
