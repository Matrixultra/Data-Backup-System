package com.backup.io;

import com.backup.data.BackupData;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Handles JSON serialization/deserialization of BackupData.
 *
 * NOTE ON DEPENDENCIES:
 * The project brief calls for Jackson or Gson. This environment has no
 * network access to fetch those jars, so this class ships a small,
 * dependency-free JSON reader/writer that covers exactly the data shapes
 * used by BackupData (strings, integers, doubles, booleans, and flat maps).
 *
 * If you have internet access when you build this project, you can drop
 * Gson in instead with about 10 lines of change. See README.md ->
 * "Swapping in Gson/Jackson" for the exact snippet. Using Gson would look
 * like:
 *
 *   Gson gson = new GsonBuilder().setPrettyPrinting().create();
 *   String json = gson.toJson(backup);
 *   Files.write(Paths.get(filePath), json.getBytes());
 *
 * The hand-rolled parser below is intentionally simple/readable rather than
 * a general-purpose JSON engine, since it only needs to round-trip the
 * key/value + metadata shape used throughout this system.
 */
public class JSONHandler {

    public void exportToJSON(BackupData backup, String filePath) throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"backupId\": \"").append(esc(backup.getBackupId())).append("\",\n");
        sb.append("  \"backupTime\": ").append(backup.getBackupTime().getTime()).append(",\n");
        sb.append("  \"description\": \"").append(esc(backup.getDescription())).append("\",\n");
        sb.append("  \"data\": {\n");

        int i = 0;
        int n = backup.getData().size();
        for (Map.Entry<String, Object> entry : backup.getData().entrySet()) {
            sb.append("    \"").append(esc(entry.getKey())).append("\": ");
            sb.append(formatValue(entry.getValue()));
            i++;
            if (i < n) sb.append(",");
            sb.append("\n");
        }

        sb.append("  }\n");
        sb.append("}\n");

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(sb.toString());
        }
    }

    public BackupData importFromJSON(String filePath) throws IOException {
        StringBuilder raw = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                raw.append(line).append("\n");
            }
        }

        SimpleJsonParser parser = new SimpleJsonParser(raw.toString());
        Map<String, Object> root = parser.parseObject();

        String backupId = (String) root.getOrDefault("backupId", java.util.UUID.randomUUID().toString());
        long backupTime = root.containsKey("backupTime")
                ? ((Number) root.get("backupTime")).longValue()
                : System.currentTimeMillis();
        String description = (String) root.getOrDefault("description", "Imported from JSON");

        @SuppressWarnings("unchecked")
        Map<String, Object> data = root.containsKey("data")
                ? (Map<String, Object>) root.get("data")
                : new LinkedHashMap<>();

        return new BackupData(backupId, new Date(backupTime), description, data);
    }

    private String formatValue(Object value) {
        if (value == null) return "null";
        if (value instanceof String) return "\"" + esc((String) value) + "\"";
        if (value instanceof Boolean || value instanceof Integer
                || value instanceof Long || value instanceof Double
                || value instanceof Float) {
            return value.toString();
        }
        return "\"" + esc(value.toString()) + "\"";
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "");
    }

    /**
     * Minimal recursive-descent JSON object parser supporting the flat
     * shapes produced by exportToJSON: strings, numbers, booleans, null,
     * and one level of nested object (the "data" map).
     */
    private static class SimpleJsonParser {
        private final String json;
        private int pos = 0;

        SimpleJsonParser(String json) {
            this.json = json;
        }

        Map<String, Object> parseObject() {
            skipWhitespace();
            expect('{');
            Map<String, Object> result = new LinkedHashMap<>();
            skipWhitespace();
            if (peek() == '}') {
                pos++;
                return result;
            }
            while (true) {
                skipWhitespace();
                String key = parseString();
                skipWhitespace();
                expect(':');
                skipWhitespace();
                Object value = parseValue();
                result.put(key, value);
                skipWhitespace();
                char c = next();
                if (c == '}') break;
                if (c != ',') throw new RuntimeException("Expected ',' or '}' at pos " + pos);
            }
            return result;
        }

        private Object parseValue() {
            skipWhitespace();
            char c = peek();
            if (c == '"') return parseString();
            if (c == '{') return parseObject();
            if (c == 't' || c == 'f') return parseBoolean();
            if (c == 'n') { pos += 4; return null; }
            return parseNumber();
        }

        private String parseString() {
            expect('"');
            StringBuilder sb = new StringBuilder();
            while (peek() != '"') {
                char c = next();
                if (c == '\\') {
                    char esc = next();
                    switch (esc) {
                        case 'n': sb.append('\n'); break;
                        case 'r': break;
                        case '"': sb.append('"'); break;
                        case '\\': sb.append('\\'); break;
                        default: sb.append(esc);
                    }
                } else {
                    sb.append(c);
                }
            }
            pos++; // closing quote
            return sb.toString();
        }

        private Boolean parseBoolean() {
            if (json.startsWith("true", pos)) {
                pos += 4;
                return true;
            } else {
                pos += 5;
                return false;
            }
        }

        private Number parseNumber() {
            int start = pos;
            while (pos < json.length() &&
                    (Character.isDigit(peek()) || peek() == '-' || peek() == '.' || peek() == 'e' || peek() == 'E' || peek() == '+')) {
                pos++;
            }
            String numStr = json.substring(start, pos);
            if (numStr.contains(".") || numStr.contains("e") || numStr.contains("E")) {
                return Double.parseDouble(numStr);
            }
            try {
                return Integer.parseInt(numStr);
            } catch (NumberFormatException e) {
                return Long.parseLong(numStr);
            }
        }

        private void skipWhitespace() {
            while (pos < json.length() && Character.isWhitespace(json.charAt(pos))) pos++;
        }

        private char peek() {
            return json.charAt(pos);
        }

        private char next() {
            return json.charAt(pos++);
        }

        private void expect(char c) {
            if (peek() != c) throw new RuntimeException("Expected '" + c + "' at pos " + pos + " but found '" + peek() + "'");
            pos++;
        }
    }
}
