package com.backup.io;

import com.backup.data.BackupData;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * Handles plain (uncompressed) binary serialization of BackupData objects
 * using Java's native Serializable mechanism.
 */
public class BinarySerializer {

    public void save(BackupData backup, String filePath) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            oos.writeObject(backup);
        }
    }

    public BackupData load(String filePath) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
            Object obj = ois.readObject();
            if (!(obj instanceof BackupData)) {
                throw new IOException("File does not contain a valid BackupData object: " + filePath);
            }
            return (BackupData) obj;
        }
    }
}
