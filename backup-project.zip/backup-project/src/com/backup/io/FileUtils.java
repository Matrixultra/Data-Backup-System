package com.backup.io;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * General-purpose file management utilities: directory setup, size
 * calculation, copying, checksums, and comparison helpers used across
 * the backup system.
 */
public class FileUtils {

    private FileUtils() {
        // static utility class
    }

    /** Creates the directory (and parents) if it doesn't already exist. */
    public static void ensureDirectory(String dirPath) {
        File dir = new File(dirPath);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    /** Returns the size of a file in bytes, or 0 if it doesn't exist. */
    public static long sizeOf(String filePath) {
        File f = new File(filePath);
        return f.exists() ? f.length() : 0L;
    }

    /** Returns total size in bytes of all files directly inside a directory. */
    public static long totalDirectorySize(String dirPath) {
        File dir = new File(dirPath);
        if (!dir.exists() || !dir.isDirectory()) return 0L;
        File[] files = dir.listFiles();
        if (files == null) return 0L;
        long total = 0L;
        for (File f : files) {
            if (f.isFile()) {
                total += f.length();
            }
        }
        return total;
    }

    /** Copies a file, overwriting the destination if it exists. */
    public static void copyFile(String sourcePath, String destPath) throws IOException {
        Path source = Paths.get(sourcePath);
        Path dest = Paths.get(destPath);
        Files.copy(source, dest, StandardCopyOption.REPLACE_EXISTING);
    }

    /** Deletes a file if present; returns true if a file was actually deleted. */
    public static boolean deleteIfExists(String filePath) throws IOException {
        return Files.deleteIfExists(Paths.get(filePath));
    }

    /** Computes a SHA-256 checksum of a file's contents, returned as a hex string. */
    public static String sha256(String filePath) throws IOException, NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] fileBytes = Files.readAllBytes(Paths.get(filePath));
        byte[] hashBytes = digest.digest(fileBytes);
        StringBuilder sb = new StringBuilder();
        for (byte b : hashBytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    /**
     * Compares two files byte-for-byte.
     * Returns true if they are identical in content.
     */
    public static boolean filesAreIdentical(String pathA, String pathB) throws IOException {
        Path a = Paths.get(pathA);
        Path b = Paths.get(pathB);
        if (!Files.exists(a) || !Files.exists(b)) return false;
        if (Files.size(a) != Files.size(b)) return false;
        return Files.mismatch(a, b) == -1L;
    }

    /** Formats a byte count into a human-readable string (KB, MB, GB). */
    public static String humanReadableSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        int exp = (int) (Math.log(bytes) / Math.log(1024));
        String unit = "KMGTPE".charAt(exp - 1) + "B";
        double value = bytes / Math.pow(1024, exp);
        return String.format("%.1f %s", value, unit);
    }

    /** Lists files in a directory matching a given suffix (e.g. ".dat"). */
    public static File[] listFilesWithSuffix(String dirPath, String suffix) {
        File dir = new File(dirPath);
        if (!dir.exists()) return new File[0];
        File[] files = dir.listFiles((d, name) -> name.endsWith(suffix));
        return files != null ? files : new File[0];
    }
}
