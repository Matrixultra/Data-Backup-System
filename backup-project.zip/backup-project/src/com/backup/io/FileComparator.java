package com.backup.io;

import com.backup.data.BackupData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Compares two BackupData snapshots and produces a diff, plus utilities
 * to merge two backups together with configurable conflict resolution.
 */
public class FileComparator {

    /** Strategy for resolving a key that exists with different values in both backups. */
    public enum ConflictStrategy {
        PREFER_FIRST,
        PREFER_SECOND,
        PREFER_NEWEST
    }

    public static class DiffResult {
        public final List<String> onlyInFirst = new ArrayList<>();
        public final List<String> onlyInSecond = new ArrayList<>();
        public final List<String> differing = new ArrayList<>();
        public final List<String> identical = new ArrayList<>();

        public boolean hasDifferences() {
            return !onlyInFirst.isEmpty() || !onlyInSecond.isEmpty() || !differing.isEmpty();
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("Keys only in first backup (").append(onlyInFirst.size()).append("): ").append(onlyInFirst).append("\n");
            sb.append("Keys only in second backup (").append(onlyInSecond.size()).append("): ").append(onlyInSecond).append("\n");
            sb.append("Keys with differing values (").append(differing.size()).append("): ").append(differing).append("\n");
            sb.append("Identical keys (").append(identical.size()).append("): ").append(identical.size()).append(" total");
            return sb.toString();
        }
    }

    /** Compares two backups key by key and reports what changed. */
    public DiffResult compare(BackupData first, BackupData second) {
        DiffResult result = new DiffResult();
        Map<String, Object> dataA = first.getData();
        Map<String, Object> dataB = second.getData();

        Set<String> allKeys = new HashSet<>();
        allKeys.addAll(dataA.keySet());
        allKeys.addAll(dataB.keySet());

        for (String key : allKeys) {
            boolean inA = dataA.containsKey(key);
            boolean inB = dataB.containsKey(key);

            if (inA && !inB) {
                result.onlyInFirst.add(key);
            } else if (!inA && inB) {
                result.onlyInSecond.add(key);
            } else {
                Object valA = dataA.get(key);
                Object valB = dataB.get(key);
                if (java.util.Objects.equals(valA, valB)) {
                    result.identical.add(key);
                } else {
                    result.differing.add(key);
                }
            }
        }

        return result;
    }

    /**
     * Merges two backups into a new BackupData. Keys unique to either side
     * are always kept; conflicting keys are resolved per the given strategy.
     */
    public BackupData merge(BackupData first, BackupData second, ConflictStrategy strategy, String mergedDescription) {
        Map<String, Object> merged = new HashMap<>();
        Map<String, Object> dataA = first.getData();
        Map<String, Object> dataB = second.getData();

        Set<String> allKeys = new HashSet<>();
        allKeys.addAll(dataA.keySet());
        allKeys.addAll(dataB.keySet());

        boolean firstIsNewer = first.getBackupTime().after(second.getBackupTime());

        for (String key : allKeys) {
            boolean inA = dataA.containsKey(key);
            boolean inB = dataB.containsKey(key);

            if (inA && !inB) {
                merged.put(key, dataA.get(key));
            } else if (!inA && inB) {
                merged.put(key, dataB.get(key));
            } else {
                // conflict: present in both
                switch (strategy) {
                    case PREFER_FIRST:
                        merged.put(key, dataA.get(key));
                        break;
                    case PREFER_SECOND:
                        merged.put(key, dataB.get(key));
                        break;
                    case PREFER_NEWEST:
                        merged.put(key, firstIsNewer ? dataA.get(key) : dataB.get(key));
                        break;
                }
            }
        }

        return new BackupData(mergedDescription, merged);
    }
}
