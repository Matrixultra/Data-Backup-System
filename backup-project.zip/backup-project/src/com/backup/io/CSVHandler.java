package com.backup.io;

import com.backup.data.BackupData;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Handles CSV import and export for backup data.
 *
 * Export format:
 *   Key,Value,Type
 *
 * The first export also writes backup metadata (id, time, description) as
 * commented header lines (prefixed with '#') so a CSV file is fully
 * self-describing and can be round-tripped back into a BackupData object.
 */
public class CSVHandler {

    public void exportToCSV(BackupData backup, String filePath) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write("#backupId=" + backup.getBackupId() + "\n");
            writer.write("#backupTime=" + backup.getBackupTime().getTime() + "\n");
            writer.write("#description=" + escapeMeta(backup.getDescription()) + "\n");
            writer.write("Key,Value,Type\n");

            for (Map.Entry<String, Object> entry : backup.getData().entrySet()) {
                writer.write(String.format("\"%s\",\"%s\",\"%s\"\n",
                        escapeCsv(entry.getKey()),
                        escapeCsv(String.valueOf(entry.getValue())),
                        entry.getValue().getClass().getSimpleName()));
            }
        }
    }

    /** Imports a CSV previously written by exportToCSV, reconstructing a full BackupData. */
    public BackupData importBackupFromCSV(String filePath) throws IOException {
        String backupId = null;
        long backupTimeMillis = System.currentTimeMillis();
        String description = "Imported from CSV";
        Map<String, Object> data = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean headerSkipped = false;

            while ((line = reader.readLine()) != null) {
                if (line.startsWith("#backupId=")) {
                    backupId = line.substring("#backupId=".length());
                    continue;
                }
                if (line.startsWith("#backupTime=")) {
                    try {
                        backupTimeMillis = Long.parseLong(line.substring("#backupTime=".length()));
                    } catch (NumberFormatException ignored) {
                        // fall back to current time
                    }
                    continue;
                }
                if (line.startsWith("#description=")) {
                    description = line.substring("#description=".length());
                    continue;
                }
                if (!headerSkipped) {
                    // This is the "Key,Value,Type" header row
                    headerSkipped = true;
                    continue;
                }
                if (line.trim().isEmpty()) continue;

                String[] parts = parseCSVLine(line);
                if (parts.length >= 2) {
                    String key = parts[0];
                    String value = parts[1];
                    String type = parts.length > 2 ? parts[2] : "String";
                    data.put(key, convertValue(value, type));
                }
            }
        }

        if (backupId == null) {
            return new BackupData(description, data);
        }
        return new BackupData(backupId, new Date(backupTimeMillis), description, data);
    }

    /** Imports raw key/value data from any well-formed Key,Value,Type CSV (no metadata required). */
    public Map<String, Object> importFromCSV(String filePath) throws IOException {
        Map<String, Object> data = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean firstDataLine = true;

            while ((line = reader.readLine()) != null) {
                if (line.startsWith("#")) continue;
                if (firstDataLine) {
                    firstDataLine = false;
                    continue; // skip "Key,Value,Type" header
                }
                if (line.trim().isEmpty()) continue;

                String[] parts = parseCSVLine(line);
                if (parts.length >= 2) {
                    String key = parts[0];
                    String value = parts[1];
                    String type = parts.length > 2 ? parts[2] : "String";
                    data.put(key, convertValue(value, type));
                }
            }
        }

        return data;
    }

    private String[] parseCSVLine(String line) {
        List<String> result = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean inQuotes = false;

        for (char c : line.toCharArray()) {
            if (c == '"') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                result.add(current.toString());
                current = new StringBuilder();
            } else {
                current.append(c);
            }
        }
        result.add(current.toString());

        return result.toArray(new String[0]);
    }

    private Object convertValue(String value, String type) {
        try {
            switch (type) {
                case "Integer":
                    return Integer.parseInt(value);
                case "Double":
                    return Double.parseDouble(value);
                case "Long":
                    return Long.parseLong(value);
                case "Boolean":
                    return Boolean.parseBoolean(value);
                default:
                    return value;
            }
        } catch (Exception e) {
            return value; // fall back to raw string if conversion fails
        }
    }

    private String escapeCsv(String value) {
        return value.replace("\"", "\"\"");
    }

    private String escapeMeta(String value) {
        return value == null ? "" : value.replace("\n", " ");
    }
}
