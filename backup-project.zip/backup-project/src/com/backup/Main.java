package com.backup;

import com.backup.data.BackupData;
import com.backup.data.RecoveryPoint;
import com.backup.io.FileComparator;
import com.backup.io.FileUtils;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Console entry point for the Data Backup System. Presents a menu-driven
 * interface for creating backups, restoring them, importing data, managing
 * versions and recovery points, and viewing statistics.
 */
public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final BackupManager manager = new BackupManager();

    public static void main(String[] args) {
        boolean running = true;

        while (running) {
            printMenu();
            String choice = scanner.nextLine().trim();

            try {
                switch (choice) {
                    case "1": createBackupFlow(); break;
                    case "2": restoreFromBinaryFlow(); break;
                    case "3": restoreFromCompressedFlow(); break;
                    case "4": importFromCSVFlow(); break;
                    case "5": listVersionsFlow(); break;
                    case "6": cleanupFlow(); break;
                    case "7": statisticsFlow(); break;
                    case "8": compareBackupsFlow(); break;
                    case "9": listRecoveryPointsFlow(); break;
                    case "10": running = false; break;
                    default: System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }

            if (running) {
                System.out.println();
            }
        }

        manager.shutdownScheduler();
        System.out.println("Goodbye!");
    }

    private static void printMenu() {
        System.out.println("=== DATA BACKUP SYSTEM ===");
        System.out.println("1. Create New Backup");
        System.out.println("2. Restore from Binary");
        System.out.println("3. Restore from Compressed");
        System.out.println("4. Import from CSV");
        System.out.println("5. List All Versions");
        System.out.println("6. Cleanup Old Backups");
        System.out.println("7. Backup Statistics");
        System.out.println("8. Compare Two Backups");
        System.out.println("9. List Recovery Points");
        System.out.println("10. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void createBackupFlow() throws Exception {
        System.out.println();
        System.out.println("=== CREATE NEW BACKUP ===");
        System.out.print("Enter backup description: ");
        String description = scanner.nextLine();

        Map<String, Object> data = new HashMap<>();
        System.out.println();
        System.out.println("Enter data items (key=value, type):");

        boolean addMore = true;
        while (addMore) {
            System.out.print("Enter key: ");
            String key = scanner.nextLine();
            System.out.print("Enter value: ");
            String value = scanner.nextLine();
            System.out.print("Enter type (String/Integer/Double/Boolean): ");
            String type = scanner.nextLine();

            data.put(key, convertValue(value, type));

            System.out.print("Add more items? (y/n): ");
            addMore = scanner.nextLine().trim().equalsIgnoreCase("y");
        }

        System.out.println();
        String backupId = manager.createBackup(description, data);
        System.out.println();
        System.out.println("Backup ID: " + backupId);
    }

    private static Object convertValue(String value, String type) {
        try {
            switch (type.trim()) {
                case "Integer": return Integer.parseInt(value);
                case "Double": return Double.parseDouble(value);
                case "Boolean": return Boolean.parseBoolean(value);
                default: return value;
            }
        } catch (Exception e) {
            return value;
        }
    }

    private static void restoreFromBinaryFlow() throws Exception {
        System.out.print("Enter binary file path: ");
        String path = scanner.nextLine();
        BackupData backup = manager.restoreFromBinary(path);
        printRestoredBackup(backup);
    }

    private static void restoreFromCompressedFlow() throws Exception {
        System.out.print("Enter compressed file path: ");
        String path = scanner.nextLine();
        BackupData backup = manager.restoreFromCompressed(path);
        printRestoredBackup(backup);
    }

    private static void printRestoredBackup(BackupData backup) {
        System.out.println();
        System.out.println("RESTORED BACKUP:");
        System.out.println(backup);
        System.out.println();
        System.out.println("Data Contents:");
        int i = 1;
        for (Map.Entry<String, Object> entry : backup.getData().entrySet()) {
            System.out.printf("%d. %s = %s (%s)%n", i++, entry.getKey(), entry.getValue(),
                    entry.getValue().getClass().getSimpleName());
        }
    }

    private static void importFromCSVFlow() throws Exception {
        System.out.print("Enter CSV file path: ");
        String path = scanner.nextLine();
        Map<String, Object> data = manager.importFromCSV(path);

        System.out.println();
        System.out.println("Imported " + data.size() + " items from CSV:");
        int i = 1;
        for (Map.Entry<String, Object> entry : data.entrySet()) {
            System.out.printf("%d. %s = %s (%s)%n", i++, entry.getKey(), entry.getValue(),
                    entry.getValue().getClass().getSimpleName());
        }
    }

    private static void listVersionsFlow() throws Exception {
        List<BackupData> versions = manager.listAllVersions();

        System.out.println();
        System.out.println("=== ALL BACKUP VERSIONS ===");
        System.out.println();

        if (versions.isEmpty()) {
            System.out.println("No versions found.");
            return;
        }

        for (int i = 0; i < versions.size(); i++) {
            BackupData v = versions.get(i);
            String label = (i == 0) ? "Version 1: (Most Recent)" : "Version " + (i + 1) + ":";
            System.out.println(label);
            System.out.println(v);
            System.out.println();
        }

        System.out.println("Total Versions: " + versions.size());
        long totalSize = FileUtils.totalDirectorySize("backups");
        System.out.println("Total Backup Size: " + FileUtils.humanReadableSize(totalSize));
    }

    private static void cleanupFlow() throws Exception {
        System.out.print("Enter days to keep backups: ");
        int days = Integer.parseInt(scanner.nextLine().trim());

        System.out.println();
        System.out.println("Cleaning up backups older than " + days + " days...");
        int removed = manager.cleanupOldBackups(days);
        System.out.println("Cleanup completed! " + removed + " files removed.");
    }

    private static void statisticsFlow() {
        BackupManager.BackupStatistics stats = manager.computeStatistics();

        System.out.println();
        System.out.println("=== BACKUP STATISTICS ===");
        System.out.println("Storage Usage:");
        System.out.println("  Binary Files: " + FileUtils.humanReadableSize(stats.binarySize)
                + " (" + stats.binaryCount + " files)");
        System.out.printf("  Compressed Files: %s (%d files, %.1f%% compression)%n",
                FileUtils.humanReadableSize(stats.compressedSize), stats.compressedCount, stats.compressionRatioPercent());
        System.out.println("  CSV Files: " + FileUtils.humanReadableSize(stats.csvSize)
                + " (" + stats.csvCount + " files)");
        System.out.println("  JSON Files: " + FileUtils.humanReadableSize(stats.jsonSize)
                + " (" + stats.jsonCount + " files)");
        System.out.println("  Total Size: " + FileUtils.humanReadableSize(stats.totalSize()));
    }

    private static void compareBackupsFlow() throws Exception {
        System.out.print("Enter first binary file path: ");
        String pathA = scanner.nextLine();
        System.out.print("Enter second binary file path: ");
        String pathB = scanner.nextLine();

        BackupData a = manager.restoreFromBinary(pathA);
        BackupData b = manager.restoreFromBinary(pathB);

        FileComparator.DiffResult diff = manager.compareBackups(a, b);
        System.out.println();
        System.out.println("=== COMPARISON RESULT ===");
        System.out.println(diff);
    }

    private static void listRecoveryPointsFlow() throws Exception {
        List<RecoveryPoint> points = manager.listRecoveryPoints();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        System.out.println();
        System.out.println("=== RECOVERY POINTS ===");

        if (points.isEmpty()) {
            System.out.println("No recovery points found.");
            return;
        }

        for (RecoveryPoint p : points) {
            System.out.println("- " + p.getLabel() + " | " + sdf.format(p.getCreatedAt())
                    + " | backup id: " + p.getBackupId());
        }
    }
}
