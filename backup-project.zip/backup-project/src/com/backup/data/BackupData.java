package com.backup.data;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Core serializable data structure representing a single backup snapshot.
 * Holds an arbitrary key/value map along with metadata (id, timestamp, description).
 */
public class BackupData implements Serializable {

    private static final long serialVersionUID = 1L;

    private final String backupId;
    private final Date backupTime;
    private final Map<String, Object> data;
    private final String description;

    public BackupData(String description, Map<String, Object> data) {
        this.backupId = UUID.randomUUID().toString();
        this.backupTime = new Date();
        this.description = description;
        this.data = new HashMap<>(data);
    }

    /**
     * Constructor used when reconstructing a BackupData with a known id/time,
     * e.g. when importing from CSV/JSON where metadata already exists.
     */
    public BackupData(String backupId, Date backupTime, String description, Map<String, Object> data) {
        this.backupId = backupId;
        this.backupTime = backupTime;
        this.description = description;
        this.data = new HashMap<>(data);
    }

    public String getBackupId() {
        return backupId;
    }

    public Date getBackupTime() {
        return backupTime;
    }

    public String getDescription() {
        return description;
    }

    public Map<String, Object> getData() {
        return new HashMap<>(data);
    }

    public int size() {
        return data.size();
    }

    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return String.format(
                "Backup ID: %s%nTime: %s%nDescription: %s%nData Items: %d",
                backupId, sdf.format(backupTime), description, data.size());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BackupData)) return false;
        BackupData other = (BackupData) o;
        return backupId.equals(other.backupId);
    }

    @Override
    public int hashCode() {
        return backupId.hashCode();
    }
}
