package com.backup.data;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Represents a named, restorable recovery point that wraps a BackupData
 * snapshot together with the file paths where its various formats live.
 */
public class RecoveryPoint implements Serializable {

    private static final long serialVersionUID = 1L;

    private final String recoveryPointId;
    private final String backupId;
    private final Date createdAt;
    private final String label;
    private final String binaryPath;
    private final String compressedPath;
    private final String csvPath;
    private final String jsonPath;

    public RecoveryPoint(String recoveryPointId, String backupId, String label,
                          String binaryPath, String compressedPath,
                          String csvPath, String jsonPath) {
        this.recoveryPointId = recoveryPointId;
        this.backupId = backupId;
        this.createdAt = new Date();
        this.label = label;
        this.binaryPath = binaryPath;
        this.compressedPath = compressedPath;
        this.csvPath = csvPath;
        this.jsonPath = jsonPath;
    }

    public String getRecoveryPointId() { return recoveryPointId; }
    public String getBackupId() { return backupId; }
    public Date getCreatedAt() { return createdAt; }
    public String getLabel() { return label; }
    public String getBinaryPath() { return binaryPath; }
    public String getCompressedPath() { return compressedPath; }
    public String getCsvPath() { return csvPath; }
    public String getJsonPath() { return jsonPath; }

    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return String.format(
                "Recovery Point: %s%n  Backup ID: %s%n  Label: %s%n  Created: %s",
                recoveryPointId, backupId, label, sdf.format(createdAt));
    }
}
