# Recovery Procedures & Backup Strategy

## Recommended Backup Strategy

1. **Run `createBackup` on a schedule.** Use
   `BackupManager.scheduleAutomaticBackups(supplier, description, periodSeconds)`
   to take snapshots automatically (see Scheduling below) rather than
   relying on someone remembering to run the menu option manually.
2. **Keep at least one off-format copy.** Binary `.dat` files are fast to
   restore but only readable by this exact codebase. CSV and JSON exports
   are human-readable and easy to inspect or migrate elsewhere if the Java
   classes ever change — keep both, not just binary.
3. **Use compressed backups for long-term retention.** The `.dat.gz` files
   are typically far smaller; if disk space matters more than restore
   speed, prefer restoring from `.dat.gz` and treat plain `.dat` as a fast
   "just happened" cache that gets pruned sooner.
4. **Set a retention window with `cleanupOldBackups(keepDays)`.** Run this
   periodically (e.g. right after a scheduled backup completes) so disk
   usage doesn't grow unbounded.
5. **Name recovery points meaningfully.** When you create a backup that
   represents a known-good state (e.g. "before migration," "end of week"),
   give it a descriptive label so `listRecoveryPoints()` is actually useful
   under pressure, rather than a list of timestamps.

## Restoring a Backup

### From binary (fastest, requires matching classes)

```java
BackupManager manager = new BackupManager();
BackupData backup = manager.restoreFromBinary("backups/backup_20240115_143025.dat");
System.out.println(backup);
```

### From compressed binary

```java
BackupData backup = manager.restoreFromCompressed("backups/backup_20240115_143025.dat.gz");
```

### From CSV (when binary files are unavailable or classes have changed)

```java
Map<String, Object> rawData = manager.importFromCSV("backups/backup_20240115_143025.csv");
// or, to reconstruct a full BackupData including id/timestamp/description:
BackupData backup = manager.importBackupFromCSV("backups/backup_20240115_143025.csv");
```

### From JSON

```java
BackupData backup = manager.importFromJSON("backups/backup_20240115_143025.json");
```

### From a named Recovery Point

```java
List<RecoveryPoint> points = manager.listRecoveryPoints();
RecoveryPoint chosen = points.get(0); // most recent
BackupData backup = manager.restoreFromRecoveryPoint(chosen);
```

## Disaster Recovery Checklist

If the `backups/` directory itself is partially lost or corrupted:

1. Check `backups/versions/` first — `VersionManager` keeps an independent
   binary copy of every backup ever created, separate from the primary
   format files. `listAllVersions()` will surface anything still intact
   here even if the main `.dat`/`.csv`/`.json` files are gone.
2. Check `backups/recovery_points/` for named pointers — even if a pointer
   references a missing file path, the recovery point record itself tells
   you which `backupId` and label you're looking for, narrowing the search.
3. If only some formats survived for a given backup, prefer JSON or CSV
   over binary for recovery, since they don't require the exact original
   class definitions to read back — useful if the codebase has evolved
   since the backup was taken.
4. Use `FileUtils.sha256(filePath)` to verify a recovered file's integrity
   against a previously recorded checksum, if you maintained one.

## Comparing and Merging Backups

When two backups have diverged (e.g. taken on two different machines) and
need to be reconciled:

```java
BackupData a = manager.restoreFromBinary("backups/backup_A.dat");
BackupData b = manager.restoreFromBinary("backups/backup_B.dat");

FileComparator.DiffResult diff = manager.compareBackups(a, b);
System.out.println(diff);

BackupData merged = manager.mergeBackups(
    a, b, FileComparator.ConflictStrategy.PREFER_NEWEST, "Merged backup"
);
```

Conflict strategies:

- `PREFER_FIRST` — always keep backup A's value for a clashing key
- `PREFER_SECOND` — always keep backup B's value for a clashing key
- `PREFER_NEWEST` — keep whichever backup's value comes from the more
  recent `backupTime`

## Scheduling Automatic Backups

```java
BackupManager manager = new BackupManager();

manager.scheduleAutomaticBackups(
    () -> {
        Map<String, Object> snapshot = new HashMap<>();
        snapshot.put("users_count", currentUserCount());
        snapshot.put("database_size_mb", currentDbSizeMb());
        return snapshot;
    },
    "Scheduled nightly backup",
    24 * 60 * 60 // period in seconds = 24 hours
);

// later, to stop:
manager.stopScheduledBackups();
manager.shutdownScheduler();
```

The scheduler runs on a daemon thread, so remember to call
`shutdownScheduler()` during a clean application exit (the `Main` console
app already does this when you choose "Exit").
