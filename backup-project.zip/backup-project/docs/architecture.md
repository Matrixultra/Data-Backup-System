# Architecture & Design

## Overview

The system is organized around one core data type, `BackupData`, and four
supporting subsystems that each operate on it: I/O (serialization formats),
compression, versioning, and the top-level `BackupManager` that coordinates
them all. `Main` is a thin console UI on top of `BackupManager` — it
contains no business logic of its own.

```
                     ┌─────────────┐
                     │    Main     │   console menu
                     └──────┬──────┘
                            │
                     ┌──────▼──────┐
                     │BackupManager│   coordinator
                     └──────┬──────┘
        ┌───────────┬───────┴───────┬────────────┐
        │            │               │             │
 ┌──────▼─────┐ ┌────▼─────┐ ┌──────▼──────┐ ┌────▼────────┐
 │  io/*      │ │compression│ │  version/*  │ │  data/*     │
 │ Binary/CSV/│ │CompressionU│ │VersionMgr   │ │BackupData   │
 │ JSON/Diff  │ │tils        │ │RecoveryPtMgr│ │RecoveryPoint│
 └────────────┘ └───────────┘ │Scheduler    │ └─────────────┘
                               └─────────────┘
```

## Core Data Structure: BackupData

`BackupData` is a `Serializable` class holding:

- `backupId` — a randomly generated UUID, the canonical identifier for a
  backup across every format and subsystem
- `backupTime` — when the snapshot was taken
- `description` — a human label
- `data` — a `Map<String, Object>` of arbitrary key/value pairs (the actual
  payload being backed up)

Because the id and timestamp are fixed at construction and the object is
otherwise treated as immutable (`getData()` returns a defensive copy), the
same `BackupData` instance can be safely serialized to multiple formats
without risk of one writer mutating state another writer depends on.

## Serialization Strategy

Each format lives in its own single-responsibility class so they can be
tested, swapped, or extended independently:

- **`BinarySerializer`** — wraps Java's native `ObjectOutputStream` /
  `ObjectInputStream`. This is the most complete and lossless format since
  it serializes the JVM object graph directly.
- **`CompressionUtils`** — pipes the same `ObjectOutputStream` through a
  `GZIPOutputStream`, so compressed binary backups are produced by chaining
  streams rather than duplicating serialization logic.
- **`CSVHandler`** — exports a flattened `Key,Value,Type` table. A "Type"
  column is included so re-importing a CSV can reconstruct primitive types
  (`Integer`, `Double`, `Boolean`) instead of leaving everything as a raw
  string. Metadata (`backupId`, `backupTime`, `description`) is encoded as
  leading `#key=value` comment lines so a CSV file is self-describing and
  can be fully round-tripped back into a `BackupData`, not just a bare map.
- **`JSONHandler`** — writes the same shape as a JSON object. Because no
  external JSON library could be installed in this build environment (see
  below), it includes a small hand-rolled recursive-descent parser scoped
  to exactly the shapes this project produces: flat string/number/boolean
  values, one level of nested object for `data`, and no arrays. This is
  intentionally not a general-purpose JSON engine.

### Swapping in Gson/Jackson

If you have network access in your own environment, replacing the hand-rolled
JSON layer with Gson takes about 10 lines:

```java
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

Gson gson = new GsonBuilder().setPrettyPrinting().create();

// Export
String json = gson.toJson(backup);
Files.write(Paths.get(filePath), json.getBytes());

// Import
String content = new String(Files.readAllBytes(Paths.get(filePath)));
BackupData backup = gson.fromJson(content, BackupData.class);
```

You'd add `gson-2.10.1.jar` (or later) to the classpath and update the
`pom.xml`/`build.gradle` dependency list accordingly. The rest of the
system is unaffected since every other class talks to `JSONHandler` only
through its two public methods (`exportToJSON` / `importFromJSON`).

## Version Management

`VersionManager` stores a full binary copy of every `BackupData` ever
created, named `version_<backupId>.dat`, in a dedicated `versions/`
subfolder. Listing versions deserializes every file in that folder and
sorts by `backupTime` descending. This is a simple "keep everything"
strategy — pruning is handled separately by `BackupManager.cleanupOldBackups`,
which operates on file modification time rather than parsing each file,
so cleanup remains fast even as the version history grows.

## Recovery Points

A `RecoveryPoint` is a lightweight pointer record: it stores a label, the
originating `backupId`, and the file paths to that backup's binary,
compressed, CSV, and JSON outputs. `RecoveryPointManager` persists each one
as its own small serialized file. This separates "what versions of the data
exist" (handled by `VersionManager`) from "what's a good moment to roll back
to and where are its files" (handled by `RecoveryPointManager`) — in a
larger system these would have different retention policies, so keeping
them as separate subsystems makes that easy to add later.

## Comparison & Merge

`FileComparator` operates on two in-memory `BackupData` objects rather than
raw files, since the type information needed for a meaningful diff (is this
value the same string, the same number) only exists once a backup has been
deserialized. `compare()` buckets every key into "only in first," "only in
second," "differing," or "identical." `merge()` reuses that same key
classification, then applies one of three conflict strategies
(`PREFER_FIRST`, `PREFER_SECOND`, `PREFER_NEWEST`) to keys present in both
backups with different values.

## Scheduling

`BackupScheduler` wraps a single-thread `ScheduledExecutorService` running
as a daemon thread, so it never blocks JVM shutdown if the user forgets to
call `shutdown()`. `BackupManager.scheduleAutomaticBackups` accepts a
`Supplier<Map<String, Object>>` so the caller controls how a fresh data
snapshot is produced on each tick, while the scheduler itself only knows
about timing.

## Algorithmic Notes

- **CSV line parsing** uses a manual character-by-character scanner that
  tracks quote state, rather than a naive `String.split(",")`, so quoted
  values containing literal commas are not corrupted.
- **File comparison** (`FileUtils.filesAreIdentical`) uses
  `Files.mismatch()`, which is backed by an efficient buffered byte
  comparison in the JDK rather than reading both files fully into memory.
- **Checksums** use SHA-256 via `MessageDigest`, suitable for verifying
  backup file integrity after copying or archiving.
