# File Format Specifications

## Overview

Every backup created by `BackupManager.createBackup(...)` is written
simultaneously in four formats, all sharing the same `backupId` so they can
be correlated:

```
backups/backup_<yyyyMMdd_HHmmss>.dat       binary
backups/backup_<yyyyMMdd_HHmmss>.dat.gz    gzip-compressed binary
backups/backup_<yyyyMMdd_HHmmss>.csv       CSV
backups/backup_<yyyyMMdd_HHmmss>.json      JSON
```

## Binary Format (`.dat`)

Produced by `BinarySerializer` using Java's native object serialization
(`ObjectOutputStream.writeObject`). The on-disk bytes are the standard JDK
serialization stream format: a stream magic number and version, followed
by class descriptors and field data for `BackupData` and its `HashMap`
payload.

**Requirements to read this format:**
- The exact `BackupData` class (or a binary-compatible version sharing the
  same `serialValVersionUID = 1L`) must be on the classpath.
- Values inside the `data` map must themselves be `Serializable` — this
  holds for `String`, `Integer`, `Double`, `Boolean`, and other common
  wrapper types used by this project.

## Compressed Binary Format (`.dat.gz`)

Produced by `CompressionUtils.compressBackup`. This is the exact same
object-serialization stream as the `.dat` format, piped through a
`GZIPOutputStream` before hitting disk. Typical compression ratios
observed for backup data dominated by repeated small strings and numbers
are in the 60-80% size reduction range, though this varies with payload
content.

To read it, reverse the pipe: wrap a `GZIPInputStream` around the file
input stream, then read through `ObjectInputStream` as normal.

## CSV Format (`.csv`)

Plain text, UTF-8 encoded. Structure:

```
#backupId=<uuid>
#backupTime=<epoch millis>
#description=<text, newlines stripped>
Key,Value,Type
"key1","value1","String"
"key2","42","Integer"
"key3","3.14","Double"
"key4","true","Boolean"
```

- Lines starting with `#` carry metadata and are not part of the tabular
  data; they let a CSV be round-tripped back into a complete `BackupData`
  (id, timestamp, and description included) rather than just a bare map.
- The header row `Key,Value,Type` is always present immediately after the
  metadata lines.
- All three data columns are quoted. Embedded quote characters are escaped
  by doubling them (`""`), matching common CSV convention.
- The `Type` column records the Java simple class name of the original
  value (`String`, `Integer`, `Double`, `Boolean`, `Long`) so re-importing
  can reconstruct the correct primitive wrapper type instead of leaving
  every value as a string.
- Files without the `#backupId=` metadata lines can still be imported via
  `importFromCSV`, which returns a plain `Map<String, Object>` — useful for
  hand-written or externally produced CSVs like the one in
  `examples/example_backup_config.csv`.

## JSON Format (`.json`)

Plain text, UTF-8 encoded, pretty-printed with 2-space indentation:

```json
{
  "backupId": "550e8400-e29b-41d4-a716-446655440000",
  "backupTime": 1705329025000,
  "description": "User Database Backup",
  "data": {
    "users_count": 1500,
    "last_backup": "2024-01-15",
    "database_size_mb": 2450.75
  }
}
```

- `backupTime` is stored as epoch milliseconds (matching `Date.getTime()`),
  not an ISO-8601 string, to avoid any timezone ambiguity on re-import.
- Values inside `data` are emitted as native JSON types where possible:
  JSON strings for `String`, JSON numbers for `Integer`/`Long`/`Double`,
  and JSON booleans for `Boolean`. Anything else falls back to its
  `toString()` representation wrapped in quotes.
- See `docs/architecture.md` for why this project uses a small hand-rolled
  reader/writer instead of Gson/Jackson, and how to swap one in.

## Cross-Format Consistency

Because all four files for one backup share the same `backupId`, a useful
sanity check after creating a backup is to import each format independently
and confirm the same id, description, and data come back — this is exactly
what the test scenarios in `docs/testing.md` walk through.
