# Testing Evidence

This project was validated through manual walkthroughs of every menu
option and a set of targeted scenarios exercising edge cases in each
subsystem. The scenarios below describe inputs, expected behavior, and how
to reproduce them.

## Scenario 1: Round-trip a backup through all four formats

**Goal:** confirm binary, compressed, CSV, and JSON exports of the same
backup all reconstruct identical data.

1. Run the app, choose option 1 (Create New Backup).
2. Description: `User Database Backup`
3. Add three items:
   - `users_count` = `1500`, type `Integer`
   - `last_backup` = `2024-01-15`, type `String`
   - `database_size_mb` = `2450.75`, type `Double`
4. Note the printed Backup ID and file paths.
5. Choose option 2 (Restore from Binary), enter the `.dat` path.
6. Choose option 3 (Restore from Compressed), enter the `.dat.gz` path.
7. Choose option 4 (Import from CSV), enter the `.csv` path.

**Expected:** all three restores show the same three key/value pairs with
the same reconstructed types (`Integer`, `String`, `Double`), matching the
sample output in the original project brief.

## Scenario 2: CSV type coercion edge cases

**Goal:** confirm `CSVHandler.importFromCSV` degrades gracefully on bad
type hints instead of throwing.

Input CSV row: `"flag","not_a_boolean","Boolean"`

**Expected:** `Boolean.parseBoolean("not_a_boolean")` returns `false`
rather than throwing, since `Boolean.parseBoolean` only ever returns
`true` for the literal string `"true"` (case-insensitive) and `false`
otherwise — there's no parse failure to catch here, which is itself worth
noting in tests since it's a common point of confusion in code reviews.

Input CSV row: `"count","abc","Integer"`

**Expected:** `Integer.parseInt("abc")` throws `NumberFormatException`,
which `convertValue`'s catch block intercepts, falling back to returning
the raw string `"abc"` instead of crashing the import.

## Scenario 3: CSV values containing commas

**Goal:** confirm the manual quote-aware parser in `parseCSVLine` doesn't
split on commas inside quoted values.

Input CSV row: `"address","123 Main St, Suite 4","String"`

**Expected:** the value imports as the single string
`123 Main St, Suite 4`, not split into two fields. Verified by tracing
`parseCSVLine`: the `inQuotes` flag is `true` while scanning past the
internal comma, so the comma-as-delimiter branch is skipped.

## Scenario 4: Compression ratio reporting

**Goal:** confirm `BackupManager.computeStatistics()` reports a believable
compression ratio after creating several backups.

1. Create 3-4 backups with the same kind of data (e.g. similar key/value
   shapes), so binary and compressed sizes are reasonably uniform.
2. Choose option 7 (Backup Statistics).

**Expected:** the printed `Compressed Files (... compression)` percentage
is positive and well under 100% (GZIP on small structured text payloads
should land roughly in the 50-80% range based on `compressionRatioPercent`
comparing average binary size to average compressed size). If only one
format exists (e.g. binary files were deleted but compressed ones remain),
`compressionRatioPercent()` returns `0.0` rather than dividing by zero,
since it explicitly checks both counts are non-zero before computing.

## Scenario 5: Cleanup respects retention window

**Goal:** confirm `cleanupOldBackups` only deletes files older than the
given threshold.

1. Create a backup (files will have "now" as their last-modified time).
2. Choose option 6 (Cleanup Old Backups), enter `7` (days).

**Expected:** the just-created backup survives (0 files removed), since
its modification time is far newer than the 7-day cutoff. To test the
deletion path itself, you can manually back-date a file's timestamp with
`touch -d "10 days ago" backups/backup_X.dat` (on systems with GNU
`touch`) and re-run cleanup with a 7-day window — that file should then be
reported as deleted.

## Scenario 6: Version listing order

**Goal:** confirm `listAllVersions()` returns newest-first.

1. Create three backups a few seconds apart with different descriptions.
2. Choose option 5 (List All Versions).

**Expected:** "Version 1: (Most Recent)" shows the backup created last,
and the list descends chronologically — verified directly in
`VersionManager.listAllVersions()`, which sorts by
`Comparator.comparing(BackupData::getBackupTime).reversed()`.

## Scenario 7: Diff and merge with conflicting keys

**Goal:** confirm `FileComparator` correctly classifies and merges keys.

Backup A: `{name: "Alice", role: "admin"}`
Backup B: `{name: "Alice", role: "editor", region: "us-east"}`

**Expected diff:**
- identical: `[name]`
- differing: `[role]`
- onlyInSecond: `[region]`
- onlyInFirst: `[]`

**Expected merge with `PREFER_SECOND`:**
`{name: "Alice", role: "editor", region: "us-east"}`

**Expected merge with `PREFER_FIRST`:**
`{name: "Alice", role: "admin", region: "us-east"}` — note `region` is
still included since it's not a conflict, just unique to B.

## Scenario 8: Recovery point restoration

**Goal:** confirm a recovery point can restore the exact backup it was
created alongside.

1. Create a backup (a recovery point is automatically registered).
2. Choose option 9 (List Recovery Points) and confirm the label and
   backup id match what was just created.
3. In code, call `manager.restoreFromRecoveryPoint(point)` for that point
   and confirm the returned `BackupData.getBackupId()` matches.

## Known Limitations Surfaced by Testing

- The JSON parser (see `docs/architecture.md`) does not support arrays or
  more than one level of nesting, since the project's data shape never
  produces them. Hand-editing a `.json` export to add an array would break
  re-import.
- `BinarySerializer` requires the exact `BackupData` class shape (or a
  compatible `serialVersionUID`) to deserialize — this is inherent to Java
  serialization and is the reason CSV/JSON exports exist as a
  classpath-independent fallback.
